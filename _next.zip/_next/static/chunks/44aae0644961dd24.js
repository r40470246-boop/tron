(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 64891, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "warnOnce", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e => {}
}, 47170, (e, r, t) => {
    "use strict";

    function n(e, r) {
        if (void 0 === r && (r = {}), r.onlyHashChange) return void e();
        let t = document.documentElement;
        t.dataset.scrollBehavior;
        let n = t.style.scrollBehavior;
        t.style.scrollBehavior = "auto", r.dontForceLayout || t.getClientRects(), e(), t.style.scrollBehavior = n
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "disableSmoothScrollDuringRouteTransition", {
        enumerable: !0,
        get: function() {
            return n
        }
    }), e.r(64891)
}, 46400, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "HTTPAccessFallbackBoundary", {
        enumerable: !0,
        get: function() {
            return s
        }
    });
    let n = e.r(44066),
        a = e.r(2532),
        o = n._(e.r(70145)),
        c = e.r(99811),
        i = e.r(57548);
    e.r(64891);
    let u = e.r(14916);
    class l extends o.default.Component {
        componentDidCatch() {}
        static getDerivedStateFromError(e) {
            if ((0, i.isHTTPAccessFallbackError)(e)) return {
                triggeredStatus: (0, i.getAccessFallbackHTTPStatus)(e)
            };
            throw e
        }
        static getDerivedStateFromProps(e, r) {
            return e.pathname !== r.previousPathname && r.triggeredStatus ? {
                triggeredStatus: void 0,
                previousPathname: e.pathname
            } : {
                triggeredStatus: r.triggeredStatus,
                previousPathname: e.pathname
            }
        }
        render() {
            let {
                notFound: e,
                forbidden: r,
                unauthorized: t,
                children: n
            } = this.props, {
                triggeredStatus: o
            } = this.state, c = {
                [i.HTTPAccessErrorStatus.NOT_FOUND]: e,
                [i.HTTPAccessErrorStatus.FORBIDDEN]: r,
                [i.HTTPAccessErrorStatus.UNAUTHORIZED]: t
            };
            if (o) {
                let u = o === i.HTTPAccessErrorStatus.NOT_FOUND && e,
                    l = o === i.HTTPAccessErrorStatus.FORBIDDEN && r,
                    s = o === i.HTTPAccessErrorStatus.UNAUTHORIZED && t;
                return u || l || s ? (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)("meta", {
                        name: "robots",
                        content: "noindex"
                    }), !1, c[o]]
                }) : n
            }
            return n
        }
        constructor(e) {
            super(e), this.state = {
                triggeredStatus: void 0,
                previousPathname: e.pathname
            }
        }
    }

    function s(e) {
        let {
            notFound: r,
            forbidden: t,
            unauthorized: n,
            children: i
        } = e, s = (0, c.useUntrackedPathname)(), d = (0, o.useContext)(u.MissingSlotContext);
        return r || t || n ? (0, a.jsx)(l, {
            pathname: s,
            notFound: r,
            forbidden: t,
            unauthorized: n,
            missingSlots: d,
            children: i
        }) : (0, a.jsx)(a.Fragment, {
            children: i
        })
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 48809, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "useRouterBFCache", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(70145);

    function a(e, r) {
        let [t, a] = (0, n.useState)(() => ({
            tree: e,
            stateKey: r,
            next: null
        }));
        if (t.tree === e) return t;
        let o = {
                tree: e,
                stateKey: r,
                next: null
            },
            c = 1,
            i = t,
            u = o;
        for (; null !== i && c < 1;) {
            if (i.stateKey === r) {
                u.next = i.next;
                break
            } {
                c++;
                let e = {
                    tree: i.tree,
                    stateKey: i.stateKey,
                    next: null
                };
                u.next = e, u = e
            }
            i = i.next
        }
        return a(o), o
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 82230, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "default", {
        enumerable: !0,
        get: function() {
            return T
        }
    });
    let n = e.r(81258),
        a = e.r(44066),
        o = e.r(2532),
        c = e.r(45693),
        i = a._(e.r(70145)),
        u = n._(e.r(68165)),
        l = e.r(14916),
        s = e.r(40185),
        d = e.r(23437),
        f = e.r(57073),
        p = e.r(82304),
        h = e.r(47170),
        y = e.r(47634),
        g = e.r(46400),
        m = e.r(31730),
        b = e.r(78016),
        P = e.r(92062),
        _ = e.r(48809);
    e.r(64334);
    let O = u.default.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        E = ["bottom", "height", "left", "right", "top", "width", "x", "y"];

    function v(e, r) {
        let t = e.getBoundingClientRect();
        return t.top >= 0 && t.top <= r
    }
    class S extends i.default.Component {
        componentDidMount() {
            this.handlePotentialScroll()
        }
        componentDidUpdate() {
            this.props.focusAndScrollRef.apply && this.handlePotentialScroll()
        }
        render() {
            return this.props.children
        }
        constructor(...e) {
            super(...e), this.handlePotentialScroll = () => {
                let {
                    focusAndScrollRef: e,
                    segmentPath: r
                } = this.props;
                if (e.apply) {
                    if (0 !== e.segmentPaths.length && !e.segmentPaths.some(e => r.every((r, t) => (0, p.matchSegment)(r, e[t])))) return;
                    let t = null,
                        n = e.hashFragment;
                    if (n && (t = function(e) {
                            var r;
                            return "top" === e ? document.body : null != (r = document.getElementById(e)) ? r : document.getElementsByName(e)[0]
                        }(n)), t || (t = "undefined" == typeof window ? null : (0, O.findDOMNode)(this)), !(t instanceof Element)) return;
                    for (; !(t instanceof HTMLElement) || function(e) {
                            if (["sticky", "fixed"].includes(getComputedStyle(e).position)) return !0;
                            let r = e.getBoundingClientRect();
                            return E.every(e => 0 === r[e])
                        }(t);) {
                        if (null === t.nextElementSibling) return;
                        t = t.nextElementSibling
                    }
                    e.apply = !1, e.hashFragment = null, e.segmentPaths = [], (0, h.disableSmoothScrollDuringRouteTransition)(() => {
                        if (n) return void t.scrollIntoView();
                        let e = document.documentElement,
                            r = e.clientHeight;
                        !v(t, r) && (e.scrollTop = 0, v(t, r) || t.scrollIntoView())
                    }, {
                        dontForceLayout: !0,
                        onlyHashChange: e.onlyHashChange
                    }), e.onlyHashChange = !1, t.focus()
                }
            }
        }
    }

    function w(e) {
        let {
            segmentPath: r,
            children: t
        } = e, n = (0, i.useContext)(l.GlobalLayoutRouterContext);
        if (!n) throw Object.defineProperty(Error("invariant global layout router not mounted"), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: !1,
            configurable: !0
        });
        return (0, o.jsx)(S, {
            segmentPath: r,
            focusAndScrollRef: n.focusAndScrollRef,
            children: t
        })
    }

    function j(e) {
        let {
            tree: r,
            segmentPath: t,
            cacheNode: n,
            url: a
        } = e, u = (0, i.useContext)(l.GlobalLayoutRouterContext);
        if (!u) throw Object.defineProperty(Error("invariant global layout router not mounted"), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: !1,
            configurable: !0
        });
        let {
            tree: f
        } = u, h = null !== n.prefetchRsc ? n.prefetchRsc : n.rsc, y = (0, i.useDeferredValue)(n.rsc, h), g = "object" == typeof y && null !== y && "function" == typeof y.then ? (0, i.use)(y) : y;
        if (!g) {
            let e = n.lazyData;
            if (null === e) {
                let r = function e(r, t) {
                        if (r) {
                            let [n, a] = r, o = 2 === r.length;
                            if ((0, p.matchSegment)(t[0], n) && t[1].hasOwnProperty(a)) {
                                if (o) {
                                    let r = e(void 0, t[1][a]);
                                    return [t[0], {
                                        ...t[1],
                                        [a]: [r[0], r[1], r[2], "refetch"]
                                    }]
                                }
                                return [t[0], {
                                    ...t[1],
                                    [a]: e(r.slice(2), t[1][a])
                                }]
                            }
                        }
                        return t
                    }(["", ...t], f),
                    o = (0, b.hasInterceptionRouteInCurrentTree)(f),
                    l = Date.now();
                n.lazyData = e = (0, s.fetchServerResponse)(new URL(a, location.origin), {
                    flightRouterState: r,
                    nextUrl: o ? u.nextUrl : null
                }).then(e => ((0, i.startTransition)(() => {
                    (0, P.dispatchAppRouterAction)({
                        type: c.ACTION_SERVER_PATCH,
                        previousTree: f,
                        serverResponse: e,
                        navigatedAt: l
                    })
                }), e)), (0, i.use)(e)
            }(0, i.use)(d.unresolvedThenable)
        }
        return (0, o.jsx)(l.LayoutRouterContext.Provider, {
            value: {
                parentTree: r,
                parentCacheNode: n,
                parentSegmentPath: t,
                url: a
            },
            children: g
        })
    }

    function R(e) {
        let r, {
            loading: t,
            children: n
        } = e;
        if (r = "object" == typeof t && null !== t && "function" == typeof t.then ? (0, i.use)(t) : t) {
            let e = r[0],
                t = r[1],
                a = r[2];
            return (0, o.jsx)(i.Suspense, {
                fallback: (0, o.jsxs)(o.Fragment, {
                    children: [t, a, e]
                }),
                children: n
            })
        }
        return (0, o.jsx)(o.Fragment, {
            children: n
        })
    }

    function T(e) {
        let {
            parallelRouterKey: r,
            error: t,
            errorStyles: n,
            errorScripts: a,
            templateStyles: c,
            templateScripts: u,
            template: s,
            notFound: d,
            forbidden: p,
            unauthorized: h,
            segmentViewBoundaries: b
        } = e, P = (0, i.useContext)(l.LayoutRouterContext);
        if (!P) throw Object.defineProperty(Error("invariant expected layout router to be mounted"), "__NEXT_ERROR_CODE", {
            value: "E56",
            enumerable: !1,
            configurable: !0
        });
        let {
            parentTree: O,
            parentCacheNode: E,
            parentSegmentPath: v,
            url: S
        } = P, T = E.parallelRoutes, C = T.get(r);
        C || (C = new Map, T.set(r, C));
        let x = O[0],
            A = null === v ? [r] : v.concat([x, r]),
            D = O[1][r],
            M = D[0],
            k = (0, m.createRouterCacheKey)(M, !0),
            F = (0, _.useRouterBFCache)(D, k),
            I = [];
        do {
            let e = F.tree,
                r = F.stateKey,
                i = e[0],
                b = (0, m.createRouterCacheKey)(i),
                P = C.get(b);
            if (void 0 === P) {
                let e = {
                    lazyData: null,
                    rsc: null,
                    prefetchRsc: null,
                    head: null,
                    prefetchHead: null,
                    parallelRoutes: new Map,
                    loading: null,
                    navigatedAt: -1
                };
                P = e, C.set(b, e)
            }
            let _ = E.loading,
                O = (0, o.jsxs)(l.TemplateContext.Provider, {
                    value: (0, o.jsxs)(w, {
                        segmentPath: A,
                        children: [(0, o.jsx)(f.ErrorBoundary, {
                            errorComponent: t,
                            errorStyles: n,
                            errorScripts: a,
                            children: (0, o.jsx)(R, {
                                loading: _,
                                children: (0, o.jsx)(g.HTTPAccessFallbackBoundary, {
                                    notFound: d,
                                    forbidden: p,
                                    unauthorized: h,
                                    children: (0, o.jsxs)(y.RedirectBoundary, {
                                        children: [(0, o.jsx)(j, {
                                            url: S,
                                            tree: e,
                                            cacheNode: P,
                                            segmentPath: A
                                        }), null]
                                    })
                                })
                            })
                        }), null]
                    }),
                    children: [c, u, s]
                }, r);
            I.push(O), F = F.next
        } while (null !== F) return I
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 34230, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "default", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(44066),
        a = e.r(2532),
        o = n._(e.r(70145)),
        c = e.r(14916);

    function i() {
        let e = (0, o.useContext)(c.TemplateContext);
        return (0, a.jsx)(a.Fragment, {
            children: e
        })
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 63371, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), ! function(e, r) {
        for (var t in r) Object.defineProperty(e, t, {
            enumerable: !0,
            get: r[t]
        })
    }(t, {
        describeHasCheckingStringProperty: function() {
            return o
        },
        describeStringPropertyAccess: function() {
            return a
        },
        wellKnownProperties: function() {
            return c
        }
    });
    let n = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

    function a(e, r) {
        return n.test(r) ? "`" + e + "." + r + "`" : "`" + e + "[" + JSON.stringify(r) + "]`"
    }

    function o(e, r) {
        let t = JSON.stringify(r);
        return "`Reflect.has(" + e + ", " + t + ")`, `" + t + " in " + e + "`, or similar"
    }
    let c = new Set(["hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toString", "valueOf", "toLocaleString", "then", "catch", "finally", "status", "displayName", "_debugInfo", "toJSON", "$$typeof", "__esModule"])
}, 29708, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(63371),
        a = new WeakMap;

    function o(e) {
        let r = a.get(e);
        if (r) return r;
        let t = Promise.resolve(e);
        return a.set(e, t), Object.keys(e).forEach(r => {
            n.wellKnownProperties.has(r) || (t[r] = e[r])
        }), t
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 49446, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(29708).createRenderSearchParamsFromClient;
    ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 66580, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(63371),
        a = new WeakMap;

    function o(e) {
        let r = a.get(e);
        if (r) return r;
        let t = Promise.resolve(e);
        return a.set(e, t), Object.keys(e).forEach(r => {
            n.wellKnownProperties.has(r) || (t[r] = e[r])
        }), t
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 35049, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(66580).createRenderParamsFromClient;
    ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 29350, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "ReflectAdapter", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    class n {
        static get(e, r, t) {
            let n = Reflect.get(e, r, t);
            return "function" == typeof n ? n.bind(e) : n
        }
        static set(e, r, t, n) {
            return Reflect.set(e, r, t, n)
        }
        static has(e, r) {
            return Reflect.has(e, r)
        }
        static deleteProperty(e, r) {
            return Reflect.deleteProperty(e, r)
        }
    }
}, 71276, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createDedupedByCallsiteServerErrorLoggerDev", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = function(e, r) {
        if (e && e.__esModule) return e;
        if (null === e || "object" != typeof e && "function" != typeof e) return {
            default: e
        };
        var t = a(r);
        if (t && t.has(e)) return t.get(e);
        var n = {
                __proto__: null
            },
            o = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var c in e)
            if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
                var i = o ? Object.getOwnPropertyDescriptor(e, c) : null;
                i && (i.get || i.set) ? Object.defineProperty(n, c, i) : n[c] = e[c]
            } return n.default = e, t && t.set(e, n), n
    }(e.r(70145));

    function a(e) {
        if ("function" != typeof WeakMap) return null;
        var r = new WeakMap,
            t = new WeakMap;
        return (a = function(e) {
            return e ? t : r
        })(e)
    }
    let o = {
            current: null
        },
        c = "function" == typeof n.cache ? n.cache : e => e,
        i = console.warn;

    function u(e) {
        return function() {
            for (var r = arguments.length, t = Array(r), n = 0; n < r; n++) t[n] = arguments[n];
            i(e(...t))
        }
    }
    c(e => {
        try {
            i(o.current)
        } finally {
            o.current = null
        }
    })
}, 41257, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "afterTaskAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(63234).createAsyncLocalStorage)()
}, 62132, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "afterTaskAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.afterTaskAsyncStorageInstance
        }
    });
    let n = e.r(41257)
}, 54872, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), ! function(e, r) {
        for (var t in r) Object.defineProperty(e, t, {
            enumerable: !0,
            get: r[t]
        })
    }(t, {
        isRequestAPICallableInsideAfter: function() {
            return u
        },
        throwForSearchParamsAccessInUseCache: function() {
            return i
        },
        throwWithStaticGenerationBailoutError: function() {
            return o
        },
        throwWithStaticGenerationBailoutErrorWithDynamicError: function() {
            return c
        }
    });
    let n = e.r(60714),
        a = e.r(62132);

    function o(e, r) {
        throw Object.defineProperty(new n.StaticGenBailoutError("Route ".concat(e, " couldn't be rendered statically because it used ").concat(r, ". See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering")), "__NEXT_ERROR_CODE", {
            value: "E576",
            enumerable: !1,
            configurable: !0
        })
    }

    function c(e, r) {
        throw Object.defineProperty(new n.StaticGenBailoutError("Route ".concat(e, ' with `dynamic = "error"` couldn\'t be rendered statically because it used ').concat(r, ". See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering")), "__NEXT_ERROR_CODE", {
            value: "E543",
            enumerable: !1,
            configurable: !0
        })
    }

    function i(e, r) {
        let t = Object.defineProperty(Error("Route ".concat(e.route, ' used "searchParams" inside "use cache". Accessing dynamic request data inside a cache scope is not supported. If you need some search params inside a cached function await "searchParams" outside of the cached function and pass only the required search params as arguments to the cached function. See more info here: https://nextjs.org/docs/messages/next-request-in-use-cache')), "__NEXT_ERROR_CODE", {
            value: "E779",
            enumerable: !1,
            configurable: !0
        });
        throw Error.captureStackTrace(t, r), null != e.invalidDynamicUsageError || (e.invalidDynamicUsageError = t), t
    }

    function u() {
        let e = a.afterTaskAsyncStorage.getStore();
        return (null == e ? void 0 : e.rootTaskSpawnPhase) === "action"
    }
}, 99277, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), ! function(e, r) {
        for (var t in r) Object.defineProperty(e, t, {
            enumerable: !0,
            get: r[t]
        })
    }(t, {
        createPrerenderSearchParamsForClientPage: function() {
            return h
        },
        createSearchParamsFromClient: function() {
            return d
        },
        createServerSearchParamsForMetadata: function() {
            return f
        },
        createServerSearchParamsForServerPage: function() {
            return p
        },
        makeErroringSearchParamsForUseCache: function() {
            return P
        }
    });
    let n = e.r(29350),
        a = e.r(89643),
        o = e.r(83899),
        c = e.r(26894),
        i = e.r(17440),
        u = e.r(71276),
        l = e.r(63371),
        s = e.r(54872);

    function d(e, r) {
        let t = o.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return y(r, t);
            case "prerender-runtime":
                throw Object.defineProperty(new c.InvariantError("createSearchParamsFromClient should not be called in a runtime prerender."), "__NEXT_ERROR_CODE", {
                    value: "E769",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new c.InvariantError("createSearchParamsFromClient should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E739",
                    enumerable: !1,
                    configurable: !0
                });
            case "request":
                return g(e, r)
        }(0, o.throwInvariantForMissingStore)()
    }
    let f = p;

    function p(e, r) {
        let t = o.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return y(r, t);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new c.InvariantError("createServerSearchParamsForServerPage should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E747",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                var n, i;
                return n = e, i = t, (0, a.delayUntilRuntimeStage)(i, _(n));
            case "request":
                return g(e, r)
        }(0, o.throwInvariantForMissingStore)()
    }

    function h(e) {
        if (e.forceStatic) return Promise.resolve({});
        let r = o.workUnitAsyncStorage.getStore();
        if (r) switch (r.type) {
            case "prerender":
            case "prerender-client":
                return (0, i.makeHangingPromise)(r.renderSignal, e.route, "`searchParams`");
            case "prerender-runtime":
                throw Object.defineProperty(new c.InvariantError("createPrerenderSearchParamsForClientPage should not be called in a runtime prerender."), "__NEXT_ERROR_CODE", {
                    value: "E768",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new c.InvariantError("createPrerenderSearchParamsForClientPage should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E746",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-ppr":
            case "prerender-legacy":
            case "request":
                return Promise.resolve({})
        }(0, o.throwInvariantForMissingStore)()
    }

    function y(e, r) {
        if (e.forceStatic) return Promise.resolve({});
        switch (r.type) {
            case "prerender":
            case "prerender-client":
                var t = e,
                    o = r;
                let c = m.get(o);
                if (c) return c;
                let u = (0, i.makeHangingPromise)(o.renderSignal, t.route, "`searchParams`"),
                    d = new Proxy(u, {
                        get(e, r, t) {
                            if (Object.hasOwn(u, r)) return n.ReflectAdapter.get(e, r, t);
                            switch (r) {
                                case "then":
                                    return (0, a.annotateDynamicAccess)("`await searchParams`, `searchParams.then`, or similar", o), n.ReflectAdapter.get(e, r, t);
                                case "status":
                                    return (0, a.annotateDynamicAccess)("`use(searchParams)`, `searchParams.status`, or similar", o), n.ReflectAdapter.get(e, r, t);
                                default:
                                    return n.ReflectAdapter.get(e, r, t)
                            }
                        }
                    });
                return m.set(o, d), d;
            case "prerender-ppr":
            case "prerender-legacy":
                var f = e,
                    p = r;
                let h = m.get(f);
                if (h) return h;
                let y = Promise.resolve({}),
                    g = new Proxy(y, {
                        get(e, r, t) {
                            if (Object.hasOwn(y, r)) return n.ReflectAdapter.get(e, r, t);
                            switch (r) {
                                case "then": {
                                    let e = "`await searchParams`, `searchParams.then`, or similar";
                                    f.dynamicShouldError ? (0, s.throwWithStaticGenerationBailoutErrorWithDynamicError)(f.route, e) : "prerender-ppr" === p.type ? (0, a.postponeWithTracking)(f.route, e, p.dynamicTracking) : (0, a.throwToInterruptStaticGeneration)(e, f, p);
                                    return
                                }
                                case "status": {
                                    let e = "`use(searchParams)`, `searchParams.status`, or similar";
                                    f.dynamicShouldError ? (0, s.throwWithStaticGenerationBailoutErrorWithDynamicError)(f.route, e) : "prerender-ppr" === p.type ? (0, a.postponeWithTracking)(f.route, e, p.dynamicTracking) : (0, a.throwToInterruptStaticGeneration)(e, f, p);
                                    return
                                }
                                default:
                                    if ("string" == typeof r && !l.wellKnownProperties.has(r)) {
                                        let e = (0, l.describeStringPropertyAccess)("searchParams", r);
                                        f.dynamicShouldError ? (0, s.throwWithStaticGenerationBailoutErrorWithDynamicError)(f.route, e) : "prerender-ppr" === p.type ? (0, a.postponeWithTracking)(f.route, e, p.dynamicTracking) : (0, a.throwToInterruptStaticGeneration)(e, f, p)
                                    }
                                    return n.ReflectAdapter.get(e, r, t)
                            }
                        },
                        has(e, r) {
                            if ("string" == typeof r) {
                                let e = (0, l.describeHasCheckingStringProperty)("searchParams", r);
                                return f.dynamicShouldError ? (0, s.throwWithStaticGenerationBailoutErrorWithDynamicError)(f.route, e) : "prerender-ppr" === p.type ? (0, a.postponeWithTracking)(f.route, e, p.dynamicTracking) : (0, a.throwToInterruptStaticGeneration)(e, f, p), !1
                            }
                            return n.ReflectAdapter.has(e, r)
                        },
                        ownKeys() {
                            let e = "`{...searchParams}`, `Object.keys(searchParams)`, or similar";
                            f.dynamicShouldError ? (0, s.throwWithStaticGenerationBailoutErrorWithDynamicError)(f.route, e) : "prerender-ppr" === p.type ? (0, a.postponeWithTracking)(f.route, e, p.dynamicTracking) : (0, a.throwToInterruptStaticGeneration)(e, f, p)
                        }
                    });
                return m.set(f, g), g;
            default:
                return r
        }
    }

    function g(e, r) {
        return r.forceStatic ? Promise.resolve({}) : _(e)
    }
    let m = new WeakMap,
        b = new WeakMap;

    function P(e) {
        let r = b.get(e);
        if (r) return r;
        let t = Promise.resolve({}),
            a = new Proxy(t, {
                get: function r(a, o, c) {
                    return Object.hasOwn(t, o) || "string" != typeof o || "then" !== o && l.wellKnownProperties.has(o) || (0, s.throwForSearchParamsAccessInUseCache)(e, r), n.ReflectAdapter.get(a, o, c)
                },
                has: function r(t, a) {
                    return "string" != typeof a || "then" !== a && l.wellKnownProperties.has(a) || (0, s.throwForSearchParamsAccessInUseCache)(e, r), n.ReflectAdapter.has(t, a)
                },
                ownKeys: function r() {
                    (0, s.throwForSearchParamsAccessInUseCache)(e, r)
                }
            });
        return b.set(e, a), a
    }

    function _(e) {
        let r = m.get(e);
        if (r) return r;
        let t = Promise.resolve(e);
        return m.set(e, t), Object.keys(e).forEach(r => {
            l.wellKnownProperties.has(r) || Object.defineProperty(t, r, {
                get() {
                    let t = o.workUnitAsyncStorage.getStore();
                    return t && (0, a.trackDynamicDataInDynamicRender)(t), e[r]
                },
                set(e) {
                    Object.defineProperty(t, r, {
                        value: e,
                        writable: !0,
                        enumerable: !0
                    })
                },
                enumerable: !0,
                configurable: !0
            })
        }), t
    }(0, u.createDedupedByCallsiteServerErrorLoggerDev)(function(e, r) {
        return Object.defineProperty(Error("".concat(e ? 'Route "'.concat(e, '" ') : "This route ", "used ").concat(r, ". ") + "`searchParams` should be awaited before using its properties. Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis"), "__NEXT_ERROR_CODE", {
            value: "E249",
            enumerable: !1,
            configurable: !0
        })
    }), (0, u.createDedupedByCallsiteServerErrorLoggerDev)(function(e, r, t) {
        return Object.defineProperty(Error("".concat(e ? 'Route "'.concat(e, '" ') : "This route ", "used ").concat(r, ". ") + "`searchParams` should be awaited before using its properties. The following properties were not available through enumeration because they conflict with builtin or well-known property names: " + "".concat(function(e) {
            switch (e.length) {
                case 0:
                    throw Object.defineProperty(new c.InvariantError("Expected describeListOfPropertyNames to be called with a non-empty list of strings."), "__NEXT_ERROR_CODE", {
                        value: "E531",
                        enumerable: !1,
                        configurable: !0
                    });
                case 1:
                    return "`".concat(e[0], "`");
                case 2:
                    return "`".concat(e[0], "` and `").concat(e[1], "`");
                default: {
                    let r = "";
                    for (let t = 0; t < e.length - 1; t++) r += "`".concat(e[t], "`, ");
                    return r + ", and `".concat(e[e.length - 1], "`")
                }
            }
        }(t), ". ") + "Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis"), "__NEXT_ERROR_CODE", {
            value: "E2",
            enumerable: !1,
            configurable: !0
        })
    })
}, 27843, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "dynamicAccessAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(63234).createAsyncLocalStorage)()
}, 87583, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "dynamicAccessAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.dynamicAccessAsyncStorageInstance
        }
    });
    let n = e.r(27843)
}, 3060, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), ! function(e, r) {
        for (var t in r) Object.defineProperty(e, t, {
            enumerable: !0,
            get: r[t]
        })
    }(t, {
        createParamsFromClient: function() {
            return f
        },
        createPrerenderParamsForClientSegment: function() {
            return g
        },
        createServerParamsForMetadata: function() {
            return p
        },
        createServerParamsForRoute: function() {
            return h
        },
        createServerParamsForServerSegment: function() {
            return y
        }
    });
    let n = e.r(11260),
        a = e.r(29350),
        o = e.r(89643),
        c = e.r(83899),
        i = e.r(26894),
        u = e.r(63371),
        l = e.r(17440),
        s = e.r(71276),
        d = e.r(87583);

    function f(e, r) {
        let t = c.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return m(e, r, t);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new i.InvariantError("createParamsFromClient should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E736",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                throw Object.defineProperty(new i.InvariantError("createParamsFromClient should not be called in a runtime prerender."), "__NEXT_ERROR_CODE", {
                    value: "E770",
                    enumerable: !1,
                    configurable: !0
                });
            case "request":
                return O(e)
        }(0, c.throwInvariantForMissingStore)()
    }
    let p = y;

    function h(e, r) {
        let t = c.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return m(e, r, t);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new i.InvariantError("createServerParamsForRoute should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E738",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                return b(e, t);
            case "request":
                return O(e)
        }(0, c.throwInvariantForMissingStore)()
    }

    function y(e, r) {
        let t = c.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return m(e, r, t);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new i.InvariantError("createServerParamsForServerSegment should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E743",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                return b(e, t);
            case "request":
                return O(e)
        }(0, c.throwInvariantForMissingStore)()
    }

    function g(e) {
        let r = n.workAsyncStorage.getStore();
        if (!r) throw Object.defineProperty(new i.InvariantError("Missing workStore in createPrerenderParamsForClientSegment"), "__NEXT_ERROR_CODE", {
            value: "E773",
            enumerable: !1,
            configurable: !0
        });
        let t = c.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
                let a = t.fallbackRouteParams;
                if (a) {
                    for (let n in e)
                        if (a.has(n)) return (0, l.makeHangingPromise)(t.renderSignal, r.route, "`params`")
                }
                break;
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new i.InvariantError("createPrerenderParamsForClientSegment should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E734",
                    enumerable: !1,
                    configurable: !0
                })
        }
        return Promise.resolve(e)
    }

    function m(e, r, t) {
        switch (t.type) {
            case "prerender":
            case "prerender-client": {
                let o = t.fallbackRouteParams;
                if (o) {
                    for (let i in e)
                        if (o.has(i)) {
                            var n = e,
                                a = r,
                                c = t;
                            let o = P.get(n);
                            if (o) return o;
                            let i = new Proxy((0, l.makeHangingPromise)(c.renderSignal, a.route, "`params`"), _);
                            return P.set(n, i), i
                        }
                }
                break
            }
            case "prerender-ppr": {
                let n = t.fallbackRouteParams;
                if (n) {
                    for (let a in e)
                        if (n.has(a)) return function(e, r, t, n) {
                            let a = P.get(e);
                            if (a) return a;
                            let c = {
                                    ...e
                                },
                                i = Promise.resolve(c);
                            return P.set(e, i), Object.keys(e).forEach(a => {
                                u.wellKnownProperties.has(a) || (r.has(a) ? (Object.defineProperty(c, a, {
                                    get() {
                                        let e = (0, u.describeStringPropertyAccess)("params", a);
                                        "prerender-ppr" === n.type ? (0, o.postponeWithTracking)(t.route, e, n.dynamicTracking) : (0, o.throwToInterruptStaticGeneration)(e, t, n)
                                    },
                                    enumerable: !0
                                }), Object.defineProperty(i, a, {
                                    get() {
                                        let e = (0, u.describeStringPropertyAccess)("params", a);
                                        "prerender-ppr" === n.type ? (0, o.postponeWithTracking)(t.route, e, n.dynamicTracking) : (0, o.throwToInterruptStaticGeneration)(e, t, n)
                                    },
                                    set(e) {
                                        Object.defineProperty(i, a, {
                                            value: e,
                                            writable: !0,
                                            enumerable: !0
                                        })
                                    },
                                    enumerable: !0,
                                    configurable: !0
                                })) : i[a] = e[a])
                            }), i
                        }(e, n, r, t)
                }
            }
        }
        return O(e)
    }

    function b(e, r) {
        return (0, o.delayUntilRuntimeStage)(r, O(e))
    }
    let P = new WeakMap,
        _ = {
            get: function(e, r, t) {
                if ("then" === r || "catch" === r || "finally" === r) {
                    let n = a.ReflectAdapter.get(e, r, t);
                    return ({
                        [r]: function() {
                            for (var r = arguments.length, t = Array(r), a = 0; a < r; a++) t[a] = arguments[a];
                            let o = d.dynamicAccessAsyncStorage.getStore();
                            return o && o.abortController.abort(Object.defineProperty(Error("Accessed fallback `params` during prerendering."), "__NEXT_ERROR_CODE", {
                                value: "E691",
                                enumerable: !1,
                                configurable: !0
                            })), new Proxy(n.apply(e, t), _)
                        }
                    })[r]
                }
                return a.ReflectAdapter.get(e, r, t)
            }
        };

    function O(e) {
        let r = P.get(e);
        if (r) return r;
        let t = Promise.resolve(e);
        return P.set(e, t), Object.keys(e).forEach(r => {
            u.wellKnownProperties.has(r) || (t[r] = e[r])
        }), t
    }(0, s.createDedupedByCallsiteServerErrorLoggerDev)(function(e, r) {
        return Object.defineProperty(Error("".concat(e ? 'Route "'.concat(e, '" ') : "This route ", "used ").concat(r, ". ") + "`params` should be awaited before using its properties. Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis"), "__NEXT_ERROR_CODE", {
            value: "E307",
            enumerable: !1,
            configurable: !0
        })
    }), (0, s.createDedupedByCallsiteServerErrorLoggerDev)(function(e, r, t) {
        return Object.defineProperty(Error("".concat(e ? 'Route "'.concat(e, '" ') : "This route ", "used ").concat(r, ". ") + "`params` should be awaited before using its properties. The following properties were not available through enumeration because they conflict with builtin property names: " + "".concat(function(e) {
            switch (e.length) {
                case 0:
                    throw Object.defineProperty(new i.InvariantError("Expected describeListOfPropertyNames to be called with a non-empty list of strings."), "__NEXT_ERROR_CODE", {
                        value: "E531",
                        enumerable: !1,
                        configurable: !0
                    });
                case 1:
                    return "`".concat(e[0], "`");
                case 2:
                    return "`".concat(e[0], "` and `").concat(e[1], "`");
                default: {
                    let r = "";
                    for (let t = 0; t < e.length - 1; t++) r += "`".concat(e[t], "`, ");
                    return r + ", and `".concat(e[e.length - 1], "`")
                }
            }
        }(t), ". ") + "Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis"), "__NEXT_ERROR_CODE", {
            value: "E482",
            enumerable: !1,
            configurable: !0
        })
    })
}, 26694, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "ClientPageRoot", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(2532),
        a = e.r(26894);

    function o(r) {
        let {
            Component: t,
            searchParams: o,
            params: c,
            promises: i
        } = r;
        if ("undefined" == typeof window) {
            let r, i, {
                    workAsyncStorage: u
                } = e.r(11260),
                l = u.getStore();
            if (!l) throw Object.defineProperty(new a.InvariantError("Expected workStore to exist when handling searchParams in a client Page."), "__NEXT_ERROR_CODE", {
                value: "E564",
                enumerable: !1,
                configurable: !0
            });
            let {
                createSearchParamsFromClient: s
            } = e.r(99277);
            r = s(o, l);
            let {
                createParamsFromClient: d
            } = e.r(3060);
            return i = d(c, l), (0, n.jsx)(t, {
                params: i,
                searchParams: r
            })
        } {
            let {
                createRenderSearchParamsFromClient: r
            } = e.r(49446), a = r(o), {
                createRenderParamsFromClient: i
            } = e.r(35049), u = i(c);
            return (0, n.jsx)(t, {
                params: u,
                searchParams: a
            })
        }
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 36174, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "ClientSegmentRoot", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(2532),
        a = e.r(26894);

    function o(r) {
        let {
            Component: t,
            slots: o,
            params: c,
            promise: i
        } = r;
        if ("undefined" == typeof window) {
            let r, {
                    workAsyncStorage: i
                } = e.r(11260),
                u = i.getStore();
            if (!u) throw Object.defineProperty(new a.InvariantError("Expected workStore to exist when handling params in a client segment such as a Layout or Template."), "__NEXT_ERROR_CODE", {
                value: "E600",
                enumerable: !1,
                configurable: !0
            });
            let {
                createParamsFromClient: l
            } = e.r(3060);
            return r = l(c, u), (0, n.jsx)(t, {
                ...o,
                params: r
            })
        } {
            let {
                createRenderParamsFromClient: r
            } = e.r(35049), a = r(c);
            return (0, n.jsx)(t, {
                ...o,
                params: a
            })
        }
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 1421, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "IconMark", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(2532),
        a = () => "undefined" != typeof window ? null : (0, n.jsx)("meta", {
            name: "«nxt-icon»"
        })
}, 2056, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "AsyncMetadataOutlet", {
        enumerable: !0,
        get: function() {
            return c
        }
    });
    let n = e.r(2532),
        a = e.r(70145);

    function o(e) {
        let {
            promise: r
        } = e, {
            error: t,
            digest: n
        } = (0, a.use)(r);
        if (t) throw n && (t.digest = n), t;
        return null
    }

    function c(e) {
        let {
            promise: r
        } = e;
        return (0, n.jsx)(a.Suspense, {
            fallback: null,
            children: (0, n.jsx)(o, {
                promise: r
            })
        })
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}]);